#include <jni.h>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>
#include <stdexcept>
#include "llama.h"

static std::mutex guard;
static std::atomic<bool> cancelled{false};
static llama_model *model=nullptr;
static llama_context *ctx=nullptr;
static bool abort_generation(void *) { return cancelled.load(); }
static void fail(JNIEnv *e,const char *s) { e->ThrowNew(e->FindClass("java/lang/IllegalStateException"),s); }
static jbyteArray bytes(JNIEnv *e,const std::string &s) {
 auto a=e->NewByteArray((jsize)s.size());
 if(a)e->SetByteArrayRegion(a,0,(jsize)s.size(),reinterpret_cast<const jbyte *>(s.data()));
 return a;
}
static void release() { if(ctx)llama_free(ctx);ctx=nullptr;if(model)llama_model_free(model);model=nullptr; }
extern "C" JNIEXPORT void JNICALL Java_org_miraewiki_mobile_NativeAi_cancel(JNIEnv *,jclass){cancelled=true;}
extern "C" JNIEXPORT void JNICALL Java_org_miraewiki_mobile_NativeAi_unload(JNIEnv *,jclass){cancelled=true;std::lock_guard<std::mutex> l(guard);release();}
extern "C" JNIEXPORT void JNICALL Java_org_miraewiki_mobile_NativeAi_load(JNIEnv *e,jclass,jstring path,jint threads){
 std::lock_guard<std::mutex> l(guard);release();cancelled=false;
 const char *p=e->GetStringUTFChars(path,nullptr);if(!p)return;
 auto mp=llama_model_default_params();mp.n_gpu_layers=0;
 llama_backend_init();model=llama_model_load_from_file(p,mp);e->ReleaseStringUTFChars(path,p);
 if(!model){fail(e,"GGUF model could not be loaded. Check model format and available memory.");return;}
 auto cp=llama_context_default_params();cp.n_ctx=4096;cp.n_batch=256;cp.n_threads=threads;cp.n_threads_batch=threads;cp.abort_callback=abort_generation;
 ctx=llama_init_from_model(model,cp);
 if(!ctx){release();fail(e,"Not enough memory for model context.");}
}
extern "C" JNIEXPORT jbyteArray JNICALL Java_org_miraewiki_mobile_NativeAi_generate(JNIEnv *e,jclass,jbyteArray input,jint max_tokens,jobject listener){
 std::lock_guard<std::mutex> l(guard);
 if(!ctx){fail(e,"Load a GGUF model first.");return nullptr;}
 cancelled=false;llama_memory_clear(llama_get_memory(ctx),true);
 std::string text(e->GetArrayLength(input),'\0');e->GetByteArrayRegion(input,0,(jsize)text.size(),reinterpret_cast<jbyte *>(text.data()));
 llama_chat_message msg{"user",text.c_str()};const char *tmpl=llama_model_chat_template(model,nullptr);
 if(!tmpl){fail(e,"Model has no chat template.");return nullptr;}
 int n=llama_chat_apply_template(tmpl,&msg,1,true,nullptr,0);
 if(n<=0){fail(e,"Unsupported chat template. Import EXAONE 3.5 Instruct GGUF.");return nullptr;}
 std::vector<char> formatted(n+1);llama_chat_apply_template(tmpl,&msg,1,true,formatted.data(),(int)formatted.size());
 const auto *vocab=llama_model_get_vocab(model);
 int count=-llama_tokenize(vocab,formatted.data(),n,nullptr,0,true,true);
 if(count<=0||count+max_tokens+8>(int)llama_n_ctx(ctx)){fail(e,"Sources exceed context size. Use fewer source excerpts or fewer output tokens.");return nullptr;}
 std::vector<llama_token> tokens(count);llama_tokenize(vocab,formatted.data(),n,tokens.data(),count,true,true);
 auto *sampler=llama_sampler_chain_init(llama_sampler_chain_default_params());
 llama_sampler_chain_add(sampler,llama_sampler_init_temp(0.7f));llama_sampler_chain_add(sampler,llama_sampler_init_dist(42));
 std::string output;std::string error;bool ended=false;
 jclass listener_class=e->GetObjectClass(listener);jmethodID cb=e->GetMethodID(listener_class,"onText","([B)V");
 jmethodID progress=e->GetMethodID(listener_class,"onProgress","(II)V");
 e->CallVoidMethod(listener,progress,0,count);
 for(int pos=0;pos<count&&!cancelled;pos+=256){auto batch=llama_batch_get_one(tokens.data()+pos,std::min(256,count-pos));if(llama_decode(ctx,batch)!=0){if(!cancelled)error="Prompt evaluation failed.";break;}e->CallVoidMethod(listener,progress,std::min(pos+256,count),count);if(e->ExceptionCheck())break;}
 for(int i=0;i<max_tokens&&!cancelled&&error.empty();i++){
  llama_token token=llama_sampler_sample(sampler,ctx,-1);
  if(llama_vocab_is_eog(vocab,token)){ended=true;break;}
  char piece[256];int size=llama_token_to_piece(vocab,token,piece,sizeof(piece),0,true);
  if(size>=0)output.append(piece,size);else{std::vector<char> large(-size);size=llama_token_to_piece(vocab,token,large.data(),large.size(),0,true);if(size>0)output.append(large.data(),size);}
  if(i%12==0){auto a=bytes(e,output);e->CallVoidMethod(listener,cb,a);e->DeleteLocalRef(a);if(e->ExceptionCheck())break;}
  auto batch=llama_batch_get_one(&token,1);if(llama_decode(ctx,batch)!=0){if(!cancelled)error="Token evaluation failed.";break;}
 }
 llama_sampler_free(sampler);e->DeleteLocalRef(listener_class);
 if(e->ExceptionCheck())return nullptr;
 if(!error.empty()){fail(e,error.c_str());return nullptr;}
 if(!ended){
  if(cancelled.load()) output+="\n\n<!-- 미완료 초안: 생성이 중단됐습니다. -->";
  else {
   // 일부 8B/Reasoning GGUF는 완결된 답 뒤에도 EOG를 늦게 낸다. 구조가 완결되면 저장 단계로 넘긴다.
   bool complete=output.find("== 뜻 ==")!=std::string::npos && output.find("== 세계관 설계 ==")!=std::string::npos && output.find("== 플레이 활용 ==")!=std::string::npos && output.find("== 가상 예시 ==")!=std::string::npos;
   if(!complete) output+="\n\n<!-- 미완료 초안: 이 항목의 생성 길이 제한에 도달했습니다. -->";
  }
 }
 return bytes(e,output);
}
