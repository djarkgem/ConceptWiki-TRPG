package org.miraewiki.mobile;

/** Calls run on a worker thread; cancel may be called from the UI thread. */
public final class NativeAi {
 static { System.loadLibrary("mirae_ai"); }
 public interface Listener { void onText(byte[] utf8); default void onProgress(int processed,int total) {} }
 public static native void load(String path, int threads);
 public static native byte[] generate(byte[] prompt, int maxTokens, Listener listener);
 public static native void cancel();
 public static native void unload();
}
