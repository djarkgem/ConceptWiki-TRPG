package org.miraewiki.concept;

import android.webkit.CookieManager;
import org.json.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Only this fixed wiki origin receives session cookies or edit requests. */
public final class Wiki {
 public static final String ORIGIN="https://mirae.miraheze.org", API=ORIGIN+"/w/api.php";
 public interface Transport { JSONObject call(Map<String,String> params,boolean post)throws Exception; }
 public static class LoginNeeded extends IOException {public LoginNeeded(String s){super(s);}}
 private final Transport transport;
 public Wiki(){this(Wiki::request);}
 public Wiki(Transport t){transport=t;}
 public static Map<String,String> params(String... pairs){Map<String,String> p=new LinkedHashMap<>();p.put("format","json");p.put("formatversion","2");for(int i=0;i<pairs.length;i+=2)p.put(pairs[i],pairs[i+1]);return p;}
 static String encode(Map<String,String> p){StringJoiner j=new StringJoiner("&");p.forEach((k,v)->j.add(enc(k)+"="+enc(v)));return j.toString();}
 private static JSONObject request(Map<String,String> p,boolean post)throws Exception{
  String body=encode(p);HttpURLConnection c=(HttpURLConnection)new URL(API+(post?"":"?"+body)).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(45000);c.setInstanceFollowRedirects(false);c.setRequestProperty("User-Agent","ConceptWiki/0.1 (personal wiki editor)");String cookie=CookieManager.getInstance().getCookie(ORIGIN);if(cookie!=null)c.setRequestProperty("Cookie",cookie);
  try{if(post){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();if(code!=200)throw new IOException("미래위키 응답 "+code);try(InputStream in=c.getInputStream()){ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){o.write(b,0,n);if(o.size()>8*1024*1024)throw new IOException("위키 응답 크기 초과");}JSONObject j=new JSONObject(o.toString("UTF-8"));if(j.has("error")){JSONObject e=j.getJSONObject("error");String k=e.optString("code");if(k.matches("assertuserfailed|notloggedin|badtoken|permissiondenied|blocked|autoblocked"))throw new LoginNeeded("미래위키 로그인 또는 편집 권한 확인 필요: "+k);throw new IOException("미래위키: "+k+" · "+e.optString("info"));}return j;}}finally{c.disconnect();}
 }
 public static String enc(String s){try{return java.net.URLEncoder.encode(s,"UTF-8");}catch(java.io.UnsupportedEncodingException e){throw new IllegalStateException(e);}}
 public String user()throws Exception {JSONObject u=transport.call(params("action","query","meta","userinfo"),false).getJSONObject("query").getJSONObject("userinfo");if(u.optLong("id")==0)throw new LoginNeeded("미래위키에 먼저 로그인하세요.");return u.getString("name");}
 public boolean exists(String title)throws Exception {JSONArray a=transport.call(params("action","query","titles",title),false).getJSONObject("query").getJSONArray("pages");if(a.length()!=1)throw new IOException("문서 존재 여부 확인 실패");JSONObject p=a.getJSONObject(0);if(p.has("invalid"))throw new IOException("잘못된 문서 제목");return !p.optBoolean("missing",false);}
 public JSONObject create(String title,String text)throws Exception{
  user();if(exists(title))return new JSONObject().put("result","Exists");
  String token=transport.call(params("action","query","meta","tokens","type","csrf"),false).getJSONObject("query").getJSONObject("tokens").getString("csrftoken");
  JSONObject j=transport.call(params("action","edit","title",title,"text",text,"summary","EXAONE 개념 설명 자동 작성 · 정의/예시/분류","token",token,"assert","user","createonly","1","maxlag","5"),true);
  JSONObject edit=j.optJSONObject("edit");if(edit==null||!"Success".equals(edit.optString("result")))throw new LoginNeeded("게시가 완료되지 않았습니다. 로그인·인증 또는 위키 응답을 확인하세요.");return edit;
 }
}
