package org.miraewiki.concept;
import org.json.*;import java.io.*;import java.util.*;
public final class Taxonomy {
 public static String defaultPath(String title,String category){return "TRPG > 세계관 제작 > "+category+" > "+title;}
 public static String normalize(String path,String title)throws Exception{String[] nodes=path.split(">",-1);if(nodes.length<2||nodes.length>10)throw new IOException("분류는 상위 개념 > 하위 개념 > 현재 용어 형태로 2~10단계 입력하세요");List<String> clean=new ArrayList<>();for(String node:nodes){String s=Concepts.title(node);if(clean.contains(s))throw new IOException("분류 경로에 같은 항목이 반복됩니다");clean.add(s);}if(!clean.get(clean.size()-1).equals(title))throw new IOException("분류의 마지막 항목은 현재 용어와 같아야 합니다");return String.join(" > ",clean);}
 public static String header(JSONObject p)throws Exception{String path=normalize(p.getString("path"),p.getString("title"));StringJoiner out=new StringJoiner(" > ");for(String s:path.split(" > "))out.add("[["+s+"]]");return "{{미래위키여영원하라}}\n{{분류|"+out+"}}\n\n";}
}
