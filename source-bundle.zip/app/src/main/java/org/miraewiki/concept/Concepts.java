package org.miraewiki.concept;
import android.content.Context;import android.util.AtomicFile;import org.json.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.text.Normalizer;import java.util.*;
public final class Concepts {
 public static final int SCHEMA=2;
 public static final String[] CATEGORIES={"세계와 우주론","신화와 종교","마법과 초자연","종족과 문화","정치와 세력","지역과 탐험","생물과 생태","경제와 생활","전쟁과 모험","TRPG 설계와 플레이"};
 public JSONObject data;private final AtomicFile file;private final Context context;
 public Concepts(Context c)throws Exception {context=c;file=new AtomicFile(new File(c.getFilesDir(),"concepts.json"));JSONObject old=null;if(file.getBaseFile().exists())try(InputStream i=file.openRead()){old=new JSONObject(read(i));}catch(Exception ignored){}
  if(old==null||old.optInt("schema",0)<SCHEMA){data=new JSONObject().put("schema",SCHEMA).put("jobs",new JSONArray()).put("message","TRPG 1,000개 용어집 준비 완료");loadSeeds();save();}else data=old;
 }
 private static String read(InputStream i)throws Exception{ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=i.read(b))!=-1)o.write(b,0,n);return o.toString("UTF-8");}
 private void loadSeeds()throws Exception{JSONArray a=new JSONArray(read(context.getAssets().open("trpg_terms.json")));for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);add(x.getString("title"),x.getString("category"),x.getString("hint"));}}
 public JSONArray jobs()throws Exception{return data.getJSONArray("jobs");}
 public JSONObject find(String title)throws Exception{for(int i=0;i<jobs().length();i++){JSONObject p=jobs().getJSONObject(i);if(p.getString("title").equals(title))return p;}return null;}
 public static String title(String s)throws IOException{s=Normalizer.normalize(s.trim().replaceAll("\\s+"," "),Normalizer.Form.NFC);if(s.length()<1||s.length()>80||s.matches(".*[\\[\\]{}<>|#:/\\\\].*")||s.codePoints().anyMatch(Character::isISOControl))throw new IOException("용어는 1~80자로 입력하고 위키 문법이나 주소를 넣지 마세요.");return s;}
 public void add(String title,String category,String hint)throws Exception{title=title(title);if(find(title)!=null)return;boolean known=false;for(String c:CATEGORIES)if(c.equals(category))known=true;if(!known)throw new IOException("카테고리를 선택하세요");jobs().put(new JSONObject().put("title",title).put("category",category).put("hint",hint).put("path",Taxonomy.defaultPath(title,category)).put("status","대기").put("draft",""));}
 // 같은 분야를 원형으로 연결한다. 모든 문서는 최소 앞/뒤 문서에서 들어오는 링크를 받아 고아 문서가 생기지 않는다.
 public JSONArray related(JSONObject p)throws Exception{List<JSONObject> same=new ArrayList<>();for(int i=0;i<jobs().length();i++){JSONObject q=jobs().getJSONObject(i);if(q.getString("category").equals(p.getString("category")))same.add(q);}JSONArray a=new JSONArray();if(same.size()<2)return a;int at=0;for(int i=0;i<same.size();i++)if(same.get(i).getString("title").equals(p.getString("title")))at=i;int[] offsets={-1,1,-2,2,-5,5,-10,10};Set<String> seen=new LinkedHashSet<>();for(int off:offsets){String t=same.get((at+off+same.size())%same.size()).getString("title");if(!t.equals(p.getString("title")))seen.add(t);if(seen.size()>=8)break;}for(String t:seen)a.put(t);return a;}
 public void save()throws Exception{FileOutputStream o=null;try{o=file.startWrite();o.write(data.toString(2).getBytes(StandardCharsets.UTF_8));file.finishWrite(o);}catch(Exception e){if(o!=null)file.failWrite(o);throw e;}}
}
