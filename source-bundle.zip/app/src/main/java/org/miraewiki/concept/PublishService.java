package org.miraewiki.concept;
import org.miraewiki.mobile.NativeAi;
import android.app.*;import android.content.*;import android.os.*;import org.json.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.concurrent.*;
public class PublishService extends Service {
 public static volatile boolean active=false;public static volatile String status="미래위키에 올릴 개념을 선택하세요";
 private volatile boolean stopping=false;private boolean running=false;private ExecutorService executor;private PowerManager.WakeLock wake;private Concepts store;private NotificationManager notifications;
 public IBinder onBind(Intent i){return null;}
 public void onCreate(){super.onCreate();active=true;executor=Executors.newSingleThreadExecutor();notifications=getSystemService(NotificationManager.class);notifications.createNotificationChannel(new NotificationChannel("publish","개념위키 작성·게시",NotificationManager.IMPORTANCE_LOW));startForeground(21,notification("준비 중"));}
 private Notification notification(String text){PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,PublishService.class).setAction("stop"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,"publish").setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle("개념위키 · 미래위키 자동 게시").setContentText(text).setContentIntent(open).setOngoing(true).addAction(new Notification.Action.Builder(null,"중단",stop).build()).build();}
 private void progress(String s){status=s;notifications.notify(21,notification(s));}
 public int onStartCommand(Intent i,int flags,int id){if(i!=null&&"stop".equals(i.getAction())){stopping=true;NativeAi.cancel();progress("진행 중인 요청을 정리하고 중단합니다");if(!running)stopSelf();return START_NOT_STICKY;}if(running)return START_NOT_STICKY;running=true;String category=i==null?"전체":i.getStringExtra("category"),title=i==null?"":i.getStringExtra("title");int limit=i==null?1:i.getIntExtra("limit",1);executor.execute(()->run(category,title,Math.min(1000,Math.max(1,limit))));return START_NOT_STICKY;}
 private void check()throws InterruptedException {if(stopping||Thread.currentThread().isInterrupted())throw new InterruptedException();}
 private void rest()throws InterruptedException {for(int i=0;i<8;i++){check();Thread.sleep(1000);}}
 private void run(String category,String selected,int limit){boolean loaded=false;JSONObject current=null;int posted=0,processed=0;try{
  store=new Concepts(this);Wiki wiki=new Wiki();progress("미래위키 로그인 확인");wiki.user();
  File model=new File(getFilesDir(),"model.gguf");if(!model.exists())throw new IOException("연결 탭에서 GGUF 파일을 가져오세요");
  wake=getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"concept:publish");wake.acquire(3*60*60*1000L);long deadline=SystemClock.elapsedRealtime()+2*60*60*1000L;
  for(int k=0;k<store.jobs().length()&&processed<limit;k++){check();if(SystemClock.elapsedRealtime()>deadline)break;JSONObject p=store.jobs().getJSONObject(k);
   if(selected!=null&&!selected.isBlank()&&!selected.equals(p.optString("title")))continue;if(!"전체".equals(category)&&!category.equals(p.optString("category")))continue;if(!p.optString("status").matches("대기|작성 중|게시 대기"))continue;current=p;processed++;String title=p.getString("title");progress(title+" · 기존 문서 확인");
   if(wiki.exists(title)){p.put("status","기존 문서");store.save();current=null;continue;}
   if(p.optString("draft").isBlank()){
    if(!loaded){check();progress("8B GGUF 모델 불러오는 중");NativeAi.load(model.getAbsolutePath(),Math.min(4,Math.max(1,Runtime.getRuntime().availableProcessors()-1)));loaded=true;}
    check();p.put("status","작성 중");store.save();progress(title+" · 설명 작성 중");
    String raw=new String(NativeAi.generate(Writer.prompt(p).getBytes(StandardCharsets.UTF_8),1400,new NativeAi.Listener(){public void onText(byte[] b){if(stopping)NativeAi.cancel();else progress(title+" · 생성 중 "+b.length+" bytes");}public void onProgress(int n,int total){if(stopping)NativeAi.cancel();progress(title+" · "+(n<total?"용어 읽기 "+(n*100/Math.max(1,total))+"%":"설명 작성 중"));}}),StandardCharsets.UTF_8);check();p.put("raw",raw);
    try{p.put("draft",Writer.assemble(p,raw,store.related(p)));}catch(IOException e){p.put("status","보류").put("reason",e.getMessage());store.save();current=null;continue;}
   }
   p.put("status","게시 대기");store.save();check();progress(title+" · 미래위키 게시 중");JSONObject result=wiki.create(title,p.getString("draft"));p.put("status","Exists".equals(result.optString("result"))?"기존 문서":"게시 완료").put("revision",result.optLong("newrevid")).put("publishedAt",java.time.Instant.now().toString()).put("reason","");store.save();current=null;if("Success".equals(result.optString("result")))posted++;rest();
  }progress("실행 완료 · 새 문서 "+posted+"개 게시 · 목록에서 결과 확인");
 }catch(InterruptedException e){progress("중단됨 · 완료된 원고와 진행 상태 저장");}catch(Throwable e){progress("중단 · "+(e.getMessage()==null?e.toString():e.getMessage()));}
 finally{if(store!=null)try{if(current!=null&&current.optString("status").equals("작성 중"))current.put("status","대기");if(current!=null)current.put("reason",status);store.data.put("message",status);store.save();}catch(Exception ignored){}if(loaded)NativeAi.unload();if(wake!=null&&wake.isHeld())wake.release();active=false;executor.shutdown();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}}
 @Override public void onTimeout(int id,int type){stopping=true;NativeAi.cancel();stopSelf();}
 @Override public void onDestroy(){stopping=true;NativeAi.cancel();if(executor!=null)executor.shutdown();super.onDestroy();}
}
